Image Export for: document
==================================================

Folder Structure:
- Each folder represents one detected section (R1 crop)
- 00_parent_* files are the original detected sections
- Subfolders are organized by R3 classification
- Files are numbered and include R2 detection type

Total parent sections: 15
Total sub-crops: 54

Classification Summary:
  location_position: 10 items
  none: 44 items
